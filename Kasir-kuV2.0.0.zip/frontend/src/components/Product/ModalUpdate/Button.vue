<template>
  <button class="text-center px-2 py-1 bg-Abu text-white rounded-md">
    <slot></slot>
  </button>
</template>