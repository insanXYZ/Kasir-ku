<template>
  <div class="flex justify-center items-center gap-2 rounded-md py-2 text-white px-2 bg-Abu cursor-pointer">
    <slot></slot>
  </div>
</template>
