<template>
  <div class="text-center px-2 py-1 bg-Abu text-white rounded-md cursor-pointer">
    <slot></slot>
  </div>
</template> 