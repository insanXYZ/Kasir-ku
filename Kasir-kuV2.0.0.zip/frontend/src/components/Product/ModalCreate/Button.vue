<template>
  <button class="flex justify-center items-center gap-2 px-2 py-1 bg-Abu text-white rounded-md">
    <slot></slot>
  </button>
</template>