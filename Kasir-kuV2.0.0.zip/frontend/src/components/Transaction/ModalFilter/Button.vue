<template>
    <div class="bg-Abu p-1 w-full rounded-sm text-white cursor-pointer">
        <slot></slot>
    </div>
</template>