<template >
    <div class=" flex animate-pulse gap-5 items-center">
        <div class="w-[90px] h-[40px] bg-white rounded-sm">
        </div>
        <div class="w-[180px] h-[40px] bg-white rounded-sm">
        </div>
    </div>
    <div class="flex animate-pulse items-center gap-4">
        <div class="w-3/6 h-[200px] bg-white rounded-md">
        </div>
        <div class="w-2/6 h-[200px] bg-white rounded-md">
        </div>
        <div class="w-1/6 h-[200px] bg-white rounded-md">
        </div>
    </div>
    <div class="grid grid-cols-1 animate-pulse" >
        <div class="w-full bg-white h-[400px] rounded-md">
        </div>
    </div>
</template>