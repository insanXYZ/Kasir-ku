<template>
  <td class="px-6 py-4 whitespace-nowrap"><slot></slot></td>
</template>