<template>
  <div class="flex w-full gap-10 animate-pulse">
    <div class="flex w-3/5 flex-col gap-5">
      <div class="w-full h-[50px] rounded-full bg-white"></div>
      <div class="w-full h-[350px] rounded-md bg-white"></div>
    </div>
    <div class="w-2/5 bg-white rounded-md h-[400px]">
    </div>
  </div>
</template>