<template>
  <div class="w-full flex flex-col gap-5 animate-pulse">
      <div class="w-full bg-white h-[155px] rounded-md">
      </div>
      <div class="grid grid-cols-3 gap-5">
        <div class="rounded-md h-[120px] bg-white">
        </div>
        <div class="rounded-md h-[120px] bg-white">
        </div>
        <div class="rounded-md h-[120px] bg-white">
        </div>
      </div>
      <div class="w-full bg-white rounded-md h-[500px]">
      </div>
    </div>
</template>