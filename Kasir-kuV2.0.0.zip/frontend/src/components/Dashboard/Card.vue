<template>
  <div class="h-[150px] bg-white shadow-md rounded-lg px-5 flex flex-col gap-3 justify-center">
    <slot></slot>
  </div>
</template>
<script>
export default {
}
</script>